@echo off
setlocal DisableDelayedExpansion
if "%~1"=="" goto usage
if not "%~2"=="" goto usage
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply_AOEM.ps1" -SourceROM "%~f1" -OutputDirectory "%~dp0."
set "AOEM_RESULT=%ERRORLEVEL%"
goto finish
:usage
echo Drag exactly one original USA .nds ROM onto PATCH_AOEM.bat.
echo Read README_KO.txt for the supported revision and SHA256.
set "AOEM_RESULT=2"
:finish
if "%AOEM_PATCH_NO_PAUSE%"=="1" exit /b %AOEM_RESULT%
pause
exit /b %AOEM_RESULT%
