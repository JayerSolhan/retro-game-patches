﻿에이지 오브 엠파이어: 미솔로지 (Age of Empires: Mythologies) NDS 북미판 한국어 패치 v1.0
배포일: 2026-11-23

[지원 판본]
- Age of Empires: Mythologies 북미판(USA, 영어·프랑스어), 게임 코드 CEPE, 128MiB
- 원본 SHA-256: 7472036c2fa3b1adb62582f2237901b30bf3860a6ff0ac794ba6e523434edb8f
- 원본 CRC32: 0297F9EA
- 다른 지역판, 이미 패치한 롬, 트리밍한 롬에는 적용되지 않습니다.

[적용 방법 — Windows]
1. ZIP 압축을 풉니다.
2. 본인이 가진 북미판 원본 .nds 파일을 PATCH_AOEM.bat 위로 끌어다 놓습니다.
3. 같은 폴더에 AOEM_KO_v1.0.nds 파일이 만들어집니다. 원본 파일은 바뀌지 않습니다.
- Windows 기본 PowerShell로 동작하며 Python이나 별도 프로그램이 필요 없습니다.
- 지원하지 않는 롬이거나 같은 이름의 결과 파일이 이미 있으면 적용하지 않고 이유를 보여 줍니다.

[적용 방법 — macOS / Linux / 기타]
- BPS 패처(Floating IPS, Rom Patcher JS 등)로 AOEM_USA_to_KO_v1.0.bps 파일을 원본에 적용합니다.
- 만들어진 파일의 SHA-256이 아래 값과 같은지 확인하세요.

[패치 후 파일]
- SHA-256: b16ae295ed33a75ab7fb5c91d8399465151fa6ca7af0434c4c422ca5fe2c99dd
- CRC32: 515FB533

[패치 내용]
- 캠페인 대사·임무 설명, 메뉴, 유닛·건물·기술 설명 등 게임 문구 한국어화
- 한글 글꼴 추가
- DS 다운로드 플레이로 게임을 받는 쪽 기기 화면은 영어로 표시됩니다.

[주의]
- 게임 롬, 세이브, BIOS는 들어 있지 않습니다. 본인이 가진 원본을 사용하세요.
- 패치 전에 세이브 파일을 백업하세요.
- 에뮬레이터에서 확인했으며, 실물 NDS 기기에서의 동작은 보장하지 않습니다.
- 원작자 및 권리자와 무관한 비공식 팬 한국어 패치입니다. 게임의 저작권과 상표는 각 권리자에게 있습니다.

[제작 도움]
- OpenAI ChatGPT / Codex, Anthropic Claude (Claude Code)
