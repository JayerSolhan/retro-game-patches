@echo off
setlocal DisableDelayedExpansion
if "%~1"=="" goto usage
if not "%~2"=="" goto usage
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply_AEKE.ps1" -SourceROM "%~f1" -OutputDirectory "%~dp0."
set "AEKE_RESULT=%ERRORLEVEL%"
goto finish
:usage
echo Drag exactly one original USA .nds ROM onto PATCH_AEKE.bat.
echo Read README_KO.txt for the supported revision and SHA256.
set "AEKE_RESULT=2"
:finish
if "%AEKE_PATCH_NO_PAUSE%"=="1" exit /b %AEKE_RESULT%
pause
exit /b %AEKE_RESULT%
