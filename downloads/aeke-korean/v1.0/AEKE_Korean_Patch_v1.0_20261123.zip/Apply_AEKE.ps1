﻿param(
    [Parameter(Mandatory=$true)][string]$SourceROM,
    [string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules')
$temporary = $null
$ManifestSha256 = '489c75fcad5ca1e6249e4d5f458eadfc8e5133a24fca0eee9733be5303f3d0f5'

$bpsSource = @'
using System;
public static class AekeBps {
    static uint[] table;
    static uint[] Table() {
        if (table != null) return table;
        uint[] t = new uint[256];
        for (uint i = 0; i < 256; i++) {
            uint c = i;
            for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
            t[i] = c;
        }
        table = t; return t;
    }
    public static uint Crc32(byte[] d, int off, int len) {
        uint[] t = Table(); uint c = 0xFFFFFFFFu;
        for (int i = off; i < off + len; i++) c = t[(c ^ d[i]) & 0xFF] ^ (c >> 8);
        return c ^ 0xFFFFFFFFu;
    }
    static ulong Num(byte[] p, ref int pos, int end) {
        ulong v = 0, f = 1;
        while (true) {
            if (pos >= end) throw new Exception("BPS: truncated number");
            byte x = p[pos++]; v += (ulong)(x & 0x7F) * f;
            if ((x & 0x80) != 0) return v;
            f <<= 7; v += f;
        }
    }
    static uint U32(byte[] p, int o) { return (uint)(p[o] | (p[o + 1] << 8) | (p[o + 2] << 16) | (p[o + 3] << 24)); }
    public static byte[] Apply(byte[] src, byte[] patch) {
        if (patch.Length < 19 || patch[0] != 0x42 || patch[1] != 0x50 || patch[2] != 0x53 || patch[3] != 0x31)
            throw new Exception("BPS: header");
        int end = patch.Length - 12;
        if (Crc32(patch, 0, patch.Length - 4) != U32(patch, patch.Length - 4)) throw new Exception("BPS: patch CRC32");
        int pos = 4;
        long ns = (long)Num(patch, ref pos, end), nt = (long)Num(patch, ref pos, end), nm = (long)Num(patch, ref pos, end);
        pos += (int)nm;
        if (ns != src.Length || Crc32(src, 0, src.Length) != U32(patch, end)) throw new Exception("BPS: source size/CRC32");
        byte[] o = new byte[nt];
        long op = 0, srel = 0, trel = 0;
        while (pos < end) {
            ulong a = Num(patch, ref pos, end); int kind = (int)(a & 3); long n = (long)(a >> 2) + 1;
            if (op + n > nt) throw new Exception("BPS: action past end");
            if (kind == 0) {
                if (op + n > src.Length) throw new Exception("BPS: SourceRead range");
                Buffer.BlockCopy(src, (int)op, o, (int)op, (int)n);
            } else if (kind == 1) {
                if (pos + n > end) throw new Exception("BPS: TargetRead range");
                Buffer.BlockCopy(patch, pos, o, (int)op, (int)n); pos += (int)n;
            } else {
                ulong d = Num(patch, ref pos, end); long delta = (long)(d >> 1); if ((d & 1) != 0) delta = -delta;
                if (kind == 2) {
                    srel += delta;
                    if (srel < 0 || srel + n > src.Length) throw new Exception("BPS: SourceCopy range");
                    Buffer.BlockCopy(src, (int)srel, o, (int)op, (int)n); srel += n;
                } else {
                    trel += delta;
                    if (trel < 0 || trel >= op) throw new Exception("BPS: TargetCopy range");
                    for (long k = 0; k < n; k++) o[op + k] = o[trel + k];
                    trel += n;
                }
            }
            op += n;
        }
        if (op != nt) throw new Exception("BPS: target size");
        if (Crc32(o, 0, o.Length) != U32(patch, end + 4)) throw new Exception("BPS: target CRC32");
        return o;
    }
}
'@

function Get-Sha256([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-', '').ToLowerInvariant()
    } finally {
        $algorithm.Dispose()
        $stream.Dispose()
    }
}
function Get-BytesSha256([byte[]]$Data) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($Data))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose() }
}
try {
    $manifestPath = Join-Path $PSScriptRoot 'PATCH_MANIFEST.json'
    if ((Get-Sha256 $manifestPath) -ne $ManifestSha256) {
        throw '패치 정보 파일의 해시가 다릅니다. 패키지를 다시 압축 해제해 주세요.'
    }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $resolved = Resolve-Path -LiteralPath $SourceROM
    if ($resolved.Provider.Name -ne 'FileSystem' -or -not (Test-Path -LiteralPath $resolved.Path -PathType Leaf)) {
        throw '원본 ROM 파일 하나를 지정해 주세요.'
    }
    $source = $resolved.ProviderPath
    $sourceHash = Get-Sha256 $source
    $entries = @($manifest.patches | Where-Object { $_.source_sha256 -eq $sourceHash })
    if ($entries.Count -ne 1) {
        $already = @($manifest.patches | Where-Object { $_.output_sha256 -eq $sourceHash })
        if ($already.Count -gt 0) { throw '이미 이번 한글패치가 적용된 ROM입니다. 북미판 원본을 넣어 주세요.' }
        throw '지원하는 북미판 원본의 SHA256과 다릅니다. 다른 판본·이미 패치된 ROM·트리밍 ROM은 적용할 수 없습니다.'
    }
    $entry = $entries[0]
    if ((Get-Item -LiteralPath $source).Length -ne $entry.source_bytes) { throw '원본 ROM 크기가 다릅니다.' }
    if ($entry.patch -notmatch '^[A-Za-z0-9_.-]+\.bps$') { throw '패치 경로가 잘못됐습니다.' }
    $patch = Join-Path $PSScriptRoot $entry.patch
    if ((Get-Sha256 $patch) -ne $entry.patch_sha256) { throw 'BPS 패치 해시가 다릅니다. 패키지를 다시 받아 주세요.' }
    if ($entry.output_filename -notmatch '^[A-Za-z0-9_.-]+\.nds$') { throw '출력 파일 이름이 잘못됐습니다.' }
    if (-not $OutputDirectory) { $OutputDirectory = $PSScriptRoot }
    $outputRoot = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputDirectory)
    $output = Join-Path $outputRoot $entry.output_filename
    if ([string]::Equals($source, $output, [StringComparison]::OrdinalIgnoreCase)) { throw '원본과 출력 경로가 같습니다.' }
    if (Test-Path -LiteralPath $output) { throw ('출력 파일이 이미 있습니다. 덮어쓰지 않습니다: ' + $output) }
    Add-Type -TypeDefinition $bpsSource -Language CSharp
    Write-Host '패치 적용 중... (수 초 걸립니다)'
    $result = [AekeBps]::Apply([IO.File]::ReadAllBytes($source), [IO.File]::ReadAllBytes($patch))
    if ($result.Length -ne $entry.output_bytes -or (Get-BytesSha256 $result) -ne $entry.output_sha256) {
        throw '출력 ROM의 크기 또는 SHA256이 예상값과 다릅니다. 완성 파일로 저장하지 않았습니다.'
    }
    if ((Get-Sha256 $source) -ne $sourceHash) { throw '원본 파일이 검사 도중 변경됐습니다. 출력을 중단합니다.' }
    New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
    $temporary = Join-Path $outputRoot ('AEKE.partial.' + [guid]::NewGuid().ToString('N') + '.nds')
    [IO.File]::WriteAllBytes($temporary, $result)
    if ((Get-Sha256 $temporary) -ne $entry.output_sha256) { throw '저장된 출력 파일의 SHA256이 다릅니다.' }
    Move-Item -LiteralPath $temporary -Destination $output -ErrorAction Stop
    $temporary = $null
    Write-Host ('적용 및 SHA256 검증 완료: ' + $output)
    Write-Host ('SHA256: ' + $entry.output_sha256)
    Write-Host '원본 ROM과 세이브 파일은 변경하지 않았습니다.'
    Write-Host '이 패키지는 실기 미검증입니다. 실기 호환성 보장을 뜻하지 않습니다.'
    exit 0
} catch {
    [Console]::Error.WriteLine('중단: ' + $_.Exception.Message)
    exit 1
} finally {
    if ($temporary -and (Test-Path -LiteralPath $temporary -PathType Leaf)) {
        Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
    }
}
