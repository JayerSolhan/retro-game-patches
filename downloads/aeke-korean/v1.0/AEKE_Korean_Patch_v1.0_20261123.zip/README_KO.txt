﻿에이지 오브 엠파이어: 에이지 오브 킹즈 (Age of Empires: The Age of Kings) NDS 북미판 한국어 패치 v1.0
배포일: 2026-11-23

[지원 판본]
- Age of Empires: The Age of Kings 북미판(USA), 게임 코드 AEKE, Rev00, 64MiB
- 원본 SHA-256: c35ccdee3868a97d59913650587c9998b254f9b7cba64936005b49466058791c
- 원본 CRC32: F49A566E
- 다른 지역판, 다른 리비전, 이미 패치한 롬, 트리밍한 롬에는 적용되지 않습니다.

[적용 방법 — Windows]
1. ZIP 압축을 풉니다.
2. 본인이 가진 북미판 원본 .nds 파일을 PATCH_AEKE.bat 위로 끌어다 놓습니다.
3. 같은 폴더에 AEKE_KO_v1.0.nds 파일이 만들어집니다. 원본 파일은 바뀌지 않습니다.
- Windows 기본 PowerShell로 동작하며 Python이나 별도 프로그램이 필요 없습니다.
- 지원하지 않는 롬이거나 같은 이름의 결과 파일이 이미 있으면 적용하지 않고 이유를 보여 줍니다.

[적용 방법 — macOS / Linux / 기타]
- BPS 패처(Floating IPS, Rom Patcher JS 등)로 AEKE_USA_to_KO_v1.0.bps 파일을 원본에 적용합니다.
- 만들어진 파일의 SHA-256이 아래 값과 같은지 확인하세요.

[패치 후 파일]
- SHA-256: f2f41b969885e3c75cdad38b688aa2ca4464249fae1ee23ca68b2bb252e4276f
- CRC32: 44CC7A92

[패치 내용]
- 캠페인 대사·역사 설명·임무 목표, 튜토리얼, 메뉴 등 게임 문구 한국어화
- 한글 글꼴 추가
- 튜토리얼 설명 그림 일부에는 영어가 남아 있습니다.

[주의]
- 게임 롬, 세이브, BIOS는 들어 있지 않습니다. 본인이 가진 원본을 사용하세요.
- 패치 전에 세이브 파일을 백업하세요.
- 에뮬레이터에서 확인했으며, 실물 NDS 기기에서의 동작은 보장하지 않습니다.
- 원작자 및 권리자와 무관한 비공식 팬 한글패치입니다. 게임의 저작권과 상표는 각 권리자에게 있습니다.

[제작 도움]
- OpenAI ChatGPT / Codex, Anthropic Claude (Claude Code)
