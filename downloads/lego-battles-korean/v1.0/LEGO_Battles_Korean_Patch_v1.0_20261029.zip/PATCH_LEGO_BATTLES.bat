@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo LEGO Battles (USA C5SE) Korean v1.0 Patcher
echo ===========================================
set "SOURCE=%~1"
if not defined SOURCE (
  echo Drag your original USA .nds onto this BAT, or enter the full path:
  set /p "SOURCE=Original USA ROM path: "
)
if not defined SOURCE (
  echo No ROM selected.
  pause
  exit /b 1
)
"%~dp0LEGO_Battles_KO_Patcher.exe" -source "%SOURCE%" -patch "%~dp0LEGO_Battles_USA_to_KO_v1.0.bps"
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" echo Failed. Original ROM was NOT modified.
pause
exit /b %RESULT%
